package com.example.gameadblock

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import android.os.Build

class MainActivity : Activity() {

    private data class AppItem(val label: String, val pkg: String)

    private val items = ArrayList<AppItem>()
    private lateinit var listView: ListView
    private lateinit var toggleButton: Button
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Game Ad Blocker"
            textSize = 22f
            gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply {
            text = "Chọn các game offline cần chặn quảng cáo. App sẽ chặn mạng của những game này (game vẫn chơi bình thường)."
            textSize = 14f
            setPadding(0, pad / 2, 0, pad / 2)
        })

        status = TextView(this).apply { textSize = 14f }
        root.addView(status)

        toggleButton = Button(this).apply {
            setOnClickListener { onToggle() }
        }
        root.addView(toggleButton)

        listView = ListView(this).apply {
            choiceMode = ListView.CHOICE_MODE_MULTIPLE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        root.addView(listView)
        setContentView(root)

        loadApps()
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val found = pm.queryIntentActivities(launcher, 0)
                .map { it.activityInfo.applicationInfo }
                .filter { it.packageName != packageName }
                .distinctBy { it.packageName }
                .map { AppItem(pm.getApplicationLabel(it).toString(), it.packageName) }
                .sortedWith(compareByDescending<AppItem> { isGame(it.pkg) }.thenBy { it.label.lowercase() })

            runOnUiThread {
                items.clear()
                items.addAll(found)
                val adapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_list_item_multiple_choice,
                    items.map { (if (isGame(it.pkg)) "🎮 " else "") + it.label }
                )
                listView.adapter = adapter
                val saved = Prefs.getBlocked(this)
                items.forEachIndexed { i, item ->
                    listView.setItemChecked(i, item.pkg in saved)
                }
                listView.setOnItemClickListener { _, _, _, _ -> saveSelection() }
            }
        }.start()
    }

    private fun isGame(pkg: String): Boolean = try {
        val info = packageManager.getApplicationInfo(pkg, 0)
        @Suppress("DEPRECATION")
        val legacy = (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        val byCategory = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            info.category == ApplicationInfo.CATEGORY_GAME
        legacy || byCategory
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    private fun saveSelection() {
        val chosen = HashSet<String>()
        for (i in items.indices) {
            if (listView.isItemChecked(i)) chosen.add(items[i].pkg)
        }
        Prefs.setBlocked(this, chosen)
        // Nếu đang chạy thì khởi động lại để áp dụng danh sách mới.
        if (BlockVpnService.running) {
            startService(Intent(this, BlockVpnService::class.java).setAction(BlockVpnService.ACTION_STOP))
            if (chosen.isNotEmpty()) startVpnService()
        }
        refreshUi()
    }

    private fun onToggle() {
        if (BlockVpnService.running) {
            startService(Intent(this, BlockVpnService::class.java).setAction(BlockVpnService.ACTION_STOP))
            Toast.makeText(this, "Đã tắt chặn quảng cáo", Toast.LENGTH_SHORT).show()
            toggleButton.postDelayed({ refreshUi() }, 300)
            return
        }
        saveSelection()
        if (Prefs.getBlocked(this).isEmpty()) {
            Toast.makeText(this, "Hãy chọn ít nhất một game", Toast.LENGTH_SHORT).show()
            return
        }
        val prepare = VpnService.prepare(this)
        if (prepare != null) {
            @Suppress("DEPRECATION")
            startActivityForResult(prepare, REQ_VPN)
        } else {
            startVpnService()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN && resultCode == RESULT_OK) {
            startVpnService()
        }
    }

    private fun startVpnService() {
        startService(Intent(this, BlockVpnService::class.java))
        toggleButton.postDelayed({ refreshUi() }, 300)
    }

    private fun refreshUi() {
        val on = BlockVpnService.running
        toggleButton.text = if (on) "TẮT chặn quảng cáo" else "BẬT chặn quảng cáo"
        status.text = if (on) "Trạng thái: ĐANG CHẶN ✅" else "Trạng thái: đang tắt"
    }

    companion object {
        private const val REQ_VPN = 100
    }
}
