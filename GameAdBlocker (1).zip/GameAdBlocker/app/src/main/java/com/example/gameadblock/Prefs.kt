package com.example.gameadblock

import android.content.Context

object Prefs {
    private const val FILE = "game_ad_blocker"
    private const val KEY_BLOCKED = "blocked_packages"

    fun getBlocked(ctx: Context): Set<String> =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getStringSet(KEY_BLOCKED, emptySet()) ?: emptySet()

    fun setBlocked(ctx: Context, packages: Set<String>) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY_BLOCKED, HashSet(packages)).apply()
    }
}
