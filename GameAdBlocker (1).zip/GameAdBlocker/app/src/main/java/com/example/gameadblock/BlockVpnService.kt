package com.example.gameadblock

import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream

/**
 * VPN cục bộ chỉ áp dụng cho các app được chọn.
 * Mọi gói tin của các app đó bị "nuốt" (không chuyển đi đâu),
 * nên quảng cáo không tải được, còn game offline vẫn chạy bình thường.
 * Các app khác không bị ảnh hưởng.
 */
class BlockVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            stopSelf()
            return START_NOT_STICKY
        }
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (running) return
        val packages = Prefs.getBlocked(this)
        if (packages.isEmpty()) {
            stopSelf()
            return
        }

        val builder = Builder()
            .setSession("Game Ad Blocker")
            .addAddress("10.0.0.2", 32)
            .addAddress("fd00::2", 128)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)

        var added = 0
        for (pkg in packages) {
            try {
                builder.addAllowedApplication(pkg)
                added++
            } catch (_: PackageManager.NameNotFoundException) {
                // app đã bị gỡ, bỏ qua
            }
        }
        if (added == 0) {
            stopSelf()
            return
        }

        tun = builder.establish()
        val fd = tun ?: run {
            stopSelf()
            return
        }

        running = true
        worker = Thread {
            val input = FileInputStream(fd.fileDescriptor)
            val buffer = ByteArray(32767)
            try {
                // Đọc và bỏ toàn bộ gói tin => app bị chặn mạng.
                while (running && input.read(buffer) >= 0) {
                    // drop
                }
            } catch (_: Exception) {
            }
        }.also { it.start() }
    }

    private fun stopVpn() {
        running = false
        worker?.interrupt()
        worker = null
        try {
            tun?.close()
        } catch (_: Exception) {
        }
        tun = null
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    companion object {
        const val ACTION_STOP = "com.example.gameadblock.STOP"

        @Volatile
        var running = false
    }
}
