# Game Ad Blocker

App Android chặn quảng cáo cho **game offline** bằng cách chặn kết nối mạng của chính những game bạn chọn
(qua VPN cục bộ, không gửi dữ liệu ra ngoài). Game offline không cần mạng nên vẫn chơi bình thường,
còn quảng cáo thì không tải được.

## Cách build
1. Mở thư mục `GameAdBlocker` bằng **Android Studio** (bản mới, JDK 17).
2. Chờ Gradle sync xong (Android Studio tự tạo Gradle wrapper).
3. Cắm điện thoại (bật USB debugging) và bấm **Run**, hoặc `Build > Build APK(s)`.

## Cách dùng
1. Mở app, tick chọn các game muốn chặn quảng cáo (game có biểu tượng 🎮 nằm ở đầu danh sách).
2. Bấm **BẬT chặn quảng cáo**, đồng ý hộp thoại xin quyền VPN của Android.
3. Mở game và chơi. Muốn tắt thì quay lại app bấm **TẮT**.

## Lưu ý
- Chỉ các app được chọn bị chặn mạng, app khác dùng mạng bình thường.
- Chỉ phù hợp game **offline**. Game online sẽ không vào được khi bị chặn.
- Có thể thấy biểu tượng chìa khóa (VPN) trên thanh trạng thái, đó là bình thường.
- Một số game phải chờ vài giây vì quảng cáo hết thời gian tải.

## Build APK bằng GitHub (không cần Android Studio)
1. Tạo repo mới trên github.com, upload toàn bộ nội dung thư mục này (giữ nguyên thư mục `.github`).
2. Vào tab **Actions**, chọn workflow **Build APK** (tự chạy khi upload, hoặc bấm **Run workflow**).
3. Chờ khoảng 3-5 phút, mở lần chạy xong và tải file `GameAdBlocker-apk` ở mục **Artifacts**.
4. Giải nén ra `app-debug.apk`, cài lên điện thoại (cho phép cài app từ nguồn không xác định).
